package com.amer.travels.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.amer.travels.exception.ResourceNotFoundException;
import com.amer.travels.model.Travels;
import com.amer.travels.repository.TravelsRepository;

//@CrossOrigin(origins = "http://localhost:3300")
@RestController
@RequestMapping("/api/travel/")
public class TravelsController {

	@Autowired
	private TravelsRepository travelsrepo;

	// get all travels and seats
	@GetMapping("/travelsList")
	public List<Travels> getAllTravels() {
		return travelsrepo.findAll();
	}

	// create Travels rest api
	@PostMapping("/travels")
	public Travels createTravels(@RequestBody Travels travel) {
		return travelsrepo.save(travel);
	}

	// get travels by id rest api
	@GetMapping("/travless/{id}")
	public ResponseEntity<Travels> getTravelsById(@PathVariable Long id) {
		Travels travels = travelsrepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Travels not Exist with the id"));
		return ResponseEntity.ok(travels);
	}

	/// update Travels
	@PutMapping("/travelsupdate/{id}")
	public ResponseEntity<Travels> updateTravels(@PathVariable Long id, @RequestBody Travels travelsDetails) {
		Travels travel = travelsrepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Employee Not Exist with the id" + id));
		travel.setId(travelsDetails.getId());
		travel.setTravelsName(travelsDetails.getTravelsName());
		travel.setSeatsAvailable(travelsDetails.getSeatsAvailable());

		Travels updateTravels = travelsrepo.save(travel);
		return ResponseEntity.ok(updateTravels);
	}

	// delete travels
	@DeleteMapping("/travelsdelete/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteTrsavels(@PathVariable Long id) {
		Travels travel = travelsrepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("The travels not exist " + id));
		travelsrepo.delete(travel);
		Map<String, Boolean> responce = new HashMap<>();
		responce.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(responce);
	}

}
